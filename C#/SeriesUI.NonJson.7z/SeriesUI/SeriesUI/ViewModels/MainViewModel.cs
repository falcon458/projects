﻿using System.ComponentModel;
using GalaSoft.MvvmLight;

namespace SeriesUI.ViewModels
{
    internal class MainViewModel : ViewModelBase
    {
    }
}