﻿#region Copyright Vanderlande Industries B.V. 2018

// Copyright (c) 2018 Vanderlande Industries.
// All rights reserved.
//  
// The copyright to the computer program(s) herein is the property of
// Vanderlande Industries. The program(s) may be used and/or copied
// only with the written permission of the owner or in accordance with
// the terms and conditions stipulated in the contract under which the
// program(s) have been supplied.

#endregion

using System.Windows;

namespace SeriesUI.Utility
{
    public class DialogService: IDialogService
    {
        public Constants.DialogResult ShowMessageYesNoCancel(string message, string title)
        {
            var result = MessageBox.Show(message, title, MessageBoxButton.YesNoCancel);

            switch (result)
            {
                case MessageBoxResult.Yes:
                        return Constants.DialogResult.Yes;
                case MessageBoxResult.No:
                    return Constants.DialogResult.No;
                case MessageBoxResult.Cancel:
                    return Constants.DialogResult.Cancel;
                default:
                    return Constants.DialogResult.Cancel;
            }
        }

        public void ShowMessage(string message, string title = "")
        {
            MessageBox.Show(message, title);
        }
    }
}
