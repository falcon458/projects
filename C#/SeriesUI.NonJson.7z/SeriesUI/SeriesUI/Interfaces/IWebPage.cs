﻿namespace SeriesUI.Interfaces
{
    public interface IWebPage
    {
        string GetPageSource();
    }
}